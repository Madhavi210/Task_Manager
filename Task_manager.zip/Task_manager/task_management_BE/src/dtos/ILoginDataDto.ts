export interface IloginDataDto {
  email?: string;
  phoneNumber?: string;
  password: string;
}
